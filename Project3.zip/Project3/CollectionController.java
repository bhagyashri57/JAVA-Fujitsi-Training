package Project3;

import java.util.Scanner;

public class CollectionController {
	static CollectionService cs = new CollectionService();

	public static StudentCollection addStudent() throws Exception{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the Student Id:");
		int id = sc.nextInt();
		
		System.out.println("Enter the Student Name:");
		String name = sc.next();
		System.out.println("Enter the Mark1:");
		int mark1 = sc.nextInt();
		System.out.println("Enter the Mark2:");
		int mark2 = sc.nextInt();
		System.out.println("Enter the Mark3:");
		int mark3 = sc.nextInt();
					
		int t = calculateTotal(mark1, mark2, mark3);
		float per = calculatePercentage(t);
		String gra = grade(per);
		StudentCollection stu = new StudentCollection(id, name, mark1, mark2, mark3, gra);
		return stu;
	}

	static int calculateTotal(int m1, int m2, int m3) {
		return m1 + m2 + m3;
	}

	static float calculatePercentage(int t) {
		return t / 3;
	}

	static String grade(float per) {
		String g = null;
		if (per >= 90 && per < 100)
			g = "Grade A";
		else if (per >= 60 && per < 90)
			g = "Grade B";
		else if (per > 50 && per < 60)
			g = "Grade c";
		else
			g = "failed";

		return g;

	}

	static void add(StudentCollection s) {
		
		cs.add(s);
	}

	static void update() {
		cs.updateRecord();
	}
	static void delete()
	{
		cs.deleteRecord();
	}
	static void findId()
	{
		cs.findById();
	}
	static void Print()
	{
		cs.findAll();
	}
	static void generateReport()
	{
		cs.generateReport();
	}
	public static void main(String[] args) {
		int ch;
		do{
			
		System.out.println("*************Menu****************");
		System.out.println("1. ADD STUDENT RECORD \n2. VIEW BY ID\n3. VIEW ALL\n4. DELETE RECORD\n5. UPDATE RECORD\n6. GENERATE REPORT\n7. EXIT\n Enter your choice :");
		Scanner s= new Scanner(System.in);
		 ch=s.nextInt();
		switch(ch)
		{
		case 1:
			try
			{
				add(addStudent());
				throw new IdMisMatchException("Please Enter valid Id");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			break;
		case 2:
			try
			{
				findId();
				throw new IdMisMatchException("Please Enter valid Id");
			}catch(Exception e){
				System.out.println(e);
			}break;
		case 3:Print();break;
		case 4:
			try{
				delete();
				throw new IdMisMatchException("Please Enter valid Id");
			}catch(Exception e){
				System.out.println(e);
			}break;
		case 5:update();break;
		case 6:generateReport();break;
		case 7:break;
		default:System.out.println("Invalid choice....");break;
		}
		}while(ch!=7);
		
	}
}
