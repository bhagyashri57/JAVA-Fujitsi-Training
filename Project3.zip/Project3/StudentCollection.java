package Project3;

import java.util.ArrayList;

public class StudentCollection {

	private String StudName;
	private int StudId;
	private int mark1;
	private int mark2;

	public String getStudName() {
		return StudName;
	}

	public void setStudName(String studName) {
		StudName = studName;
	}

	public int getStudId() {
		return StudId;
	}

	public void setStudId(int studId) {
		StudId = studId;
	}

	public int getMark1() {
		return mark1;
	}

	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}

	public StudentCollection(int studId, String studName, int mark1, int mark2, int mark3, String grade) {
		super();
		StudId = studId;
		StudName = studName;

		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
		this.grade = grade;
	}

	public StudentCollection() {
		// TODO Auto-generated constructor stub
	}

	public int getMark2() {
		return mark2;
	}

	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}

	public int getMark3() {
		return mark3;
	}

	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	private int mark3;
	private String grade;

	@Override
	public String toString() {
		return "StudentCollection [StudName=" + StudName + ", StudId=" + StudId + ", mark1=" + mark1 + ", mark2="
				+ mark2 + ", mark3=" + mark3 + ", grade=" + grade + "]";
	}
	

}
