 package Project3;

public class CollectionException {

	
}
class IdMisMatchException extends Exception
{
    String msg;
	public IdMisMatchException(String msg) {
		this.msg=msg;
		System.out.println(msg);
	}
	

}
