package Project3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class CollectionService {
	static ArrayList<StudentCollection> al = new ArrayList<>();
	static StudentCollection sc1 = new StudentCollection();
	

	public void add(StudentCollection s) {
		al.add(s);

	}

	static void findAll() {
		for (StudentCollection e : al) {
			System.out.println(e);
		}

	}

	public static void updateRecord() {
		 int id=0;
		Scanner sc = new Scanner(System.in);
		try{
		System.out.println("Enter the id to be updated:");
		id = sc.nextInt();
		}catch(Exception e){
			
		}
		System.out.println("Enter the newname:");
		String newName = sc.next();
		Iterator<StudentCollection> it = al.iterator();
		while (it.hasNext()) {
			StudentCollection e = (StudentCollection) it.next();
			if (e.getStudId() == id) {
				e.setStudName(newName);
				break;
			}
		}
		System.out.println("Record updated successfully");
	}

	static void deleteRecord() {
		System.out.println("Enter the id to be deleted :");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		Iterator<StudentCollection> it = al.iterator();
		while (it.hasNext()) {
			StudentCollection e = (StudentCollection) it.next();
			if (e.getStudId() == id) {
				it.remove();
				break;
			}

		}

		System.out.println("Record deleted successfully");
	}

	static void findById() {
		System.out.println("Enter the Id to be found:");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		Iterator<StudentCollection> it = al.iterator();
		while (it.hasNext()) {
			StudentCollection e = (StudentCollection) it.next();
			if (e.getStudId() == id) {
				System.out.println(e.toString());
			}
		}
		System.out.println("Record found successfully");
	}
	static void generateReport()
	
	{
		System.out.println("Enter the Id to be found:");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		Iterator<StudentCollection> it = al.iterator();
		while (it.hasNext()) {
			StudentCollection sc1 = (StudentCollection) it.next();
		
	System.out.println("-------------------------------------------------------");
	System.out.println("                  Report Card                          ");
	System.out.println("-------------------------------------------------------");
	System.out.println("Name of the Student:"+sc1.getStudName());
	System.out.println("Student Id:"+sc1.getStudId());
	System.out.println("-------------------------------------------------------");
	System.out.println("Marks1:"+sc1.getMark1());
	System.out.println("Marks2:"+sc1.getMark2());
    System.out.println("Marks3:"+sc1.getMark3());
    System.out.println("-------------------------------------------------------");
    System.out.println("Grade:"+sc1.getGrade());
    System.out.println("-------------------------------------------------------");

		}	
		
	}

}
